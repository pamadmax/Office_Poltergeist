cp Resources\Wallpapers\wallpaper.jpg \\$Victim\c$\Users\Public\
$s = New-PSSession -ComputerName $Victim
Invoke-Command -Session $s -Scriptblock {C:\Users\Public\sysConf\wallpaper.ps1}
Remove-PSSession $s