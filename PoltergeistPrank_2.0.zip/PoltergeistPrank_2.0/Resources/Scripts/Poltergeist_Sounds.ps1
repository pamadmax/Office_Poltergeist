$s = New-PSSession -ComputerName $Victim
Invoke-Command -Session $s -Scriptblock {C:\Users\Public\sysConf\nircmdc.exe setsysvolume 65535 master}
Invoke-Command -Session $s -Scriptblock {C:\Users\Public\sysConf\nircmdc.exe mutesysvolume 0 master}
Invoke-Command -Session $s -Scriptblock {$PlayWav=New-Object System.Media.SoundPlayer}
Invoke-Command -Session $s -Scriptblock {$PlayWav.SoundLocation="C:\Users\Public\sysConf\sound.wav"}
Invoke-Command -Session $s -Scriptblock {$PlayWav.playsync()}
Remove-PSSession $s
Write-Output 'Done'